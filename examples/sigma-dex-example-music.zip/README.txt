Sigma Dex SSEQ pack v2. Import into a receiver that implements the versioned contract.
No original Nintendo files or HeartGold ROM are distributed.
